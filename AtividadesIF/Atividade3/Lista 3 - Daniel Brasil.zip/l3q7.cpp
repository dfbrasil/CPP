#include <iostream>
using namespace std;

int main(){

    int n = 1;
    int cont = 0;
    
    while (cont <= 15){
      
        cout << n << " ";
        n=n*3;
            
    cont++; 
    }

    cout << "\n";

return 0;

}