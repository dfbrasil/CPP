#include <iostream>
using namespace std;

int main(){

    int n=15;
    while (n <= 200){
        cout << n << "\n";
        n++;
    }
return 0;

}