#include <iostream>
using namespace std;

int main(){

   int n = 15;

    while (n < 200){

       cout << "\nO quadrado de " << n << " é: " << n*n;

       n = n + 3;
    }
    
    cout << "\n";

return 0;

}